package com.lucycato.bigtech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
